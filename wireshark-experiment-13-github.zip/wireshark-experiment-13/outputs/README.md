# Experiment Outputs

Save your Wireshark screenshots here, for example:
- `output_1_interface.png`
- `output_2_packet_capture.png`
- `output_3_display_filter.png`
- `output_4_protocol_hierarchy.png`

Only include screenshots/capture files that are safe to share. Remove or obscure sensitive addresses, hostnames, payloads, and personal information where appropriate.
