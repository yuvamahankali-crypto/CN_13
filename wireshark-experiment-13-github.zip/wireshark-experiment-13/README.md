# Experiment 13: Study of Wireshark

## Aim
To study Wireshark, a network protocol analyzer used for packet capture, packet analysis, filtering, and network troubleshooting.

## Problem Statement
- Install Wireshark on a Windows or Linux system.
- Capture live network traffic using the GUI or command line.
- Apply capture and display filters.
- Identify protocols, source/destination addresses, and packet details.
- Use statistics tools to understand network traffic.
- Save and open capture files for offline analysis.

## Requirements
- A computer with Wireshark installed
- A live network interface with internet connectivity
- Optional: a saved `.pcap` or `.pcapng` capture file

## Installation

### Windows
1. Visit the [official Wireshark website](https://www.wireshark.org/).
2. Download the installer suitable for your system.
3. Run the installer and follow the setup instructions.
4. Install **Npcap** when prompted; it is required for live packet capture.
5. Launch Wireshark and select a network interface.

### Ubuntu/Debian Linux
```bash
sudo apt update
sudo apt install wireshark
```

Depending on your system configuration, packet capture permissions may need to be configured.

## Procedure

### A. Capture packets using the GUI
1. Open Wireshark.
2. Select **Capture → Options** or choose the active interface from the start page.
3. Select the interface carrying traffic, such as Wi-Fi or Ethernet.
4. Start the capture.
5. Generate the traffic you want to inspect.
6. Click **Stop** when enough packets have been captured.
7. Select packets to inspect their protocol details and raw bytes.
8. Save the capture using **File → Save As**. The default format is `.pcapng`.

### B. Start Wireshark from the command line
Display command-line help:
```bash
wireshark -h
```

Open an existing capture:
```bash
wireshark -r capture.pcap
```

Open a capture with a display filter:
```bash
wireshark -r capture.pcap -Y "http"
```

Capture traffic from a specified interface with a capture filter:
```bash
wireshark -i <interface> -f "host 192.168.1.10" -w capture.pcap
```

Replace `<interface>` with the interface name or index available on your system. On some systems, command-line capture may require elevated permissions.

### C. View packet details
1. Select a packet in the Packet List pane.
2. Expand the protocol layers in the Packet Details pane (for example, Frame, Ethernet, IP, TCP, and HTTP).
3. Inspect source/destination addresses, ports, flags, and other fields.
4. Use the Packet Bytes pane to view hexadecimal and ASCII data.

### D. Apply filters

**Display filters** are applied to packets already captured.

| Purpose | Display filter |
|---|---|
| Show HTTP packets | `http` |
| Show packets from a source IP | `ip.src == 192.168.1.10` |
| Show packets to or from an IP | `ip.addr == 192.168.1.10` |
| Show TCP traffic | `tcp` |
| Show DNS traffic | `dns` |

**Capture filters** limit what is collected during capture.

| Purpose | Capture filter |
|---|---|
| Capture traffic to/from a host | `host 192.168.1.10` |
| Capture TCP port 80 traffic | `tcp port 80` |
| Capture port 443 traffic | `port 443` |

Note: modern websites usually use HTTPS, so an `http` display filter may show little or no traffic. Port 80 is commonly associated with HTTP; port 443 is commonly associated with HTTPS.

### E. Analyze statistics
From the **Statistics** menu, explore:
- **Protocol Hierarchy** — protocol breakdown by packets and bytes
- **Endpoints** — communicating network endpoints
- **Conversations** — traffic exchanged between endpoint pairs
- **I/O Graphs** — traffic volume over time
- **Packet Lengths** — distribution of packet sizes

### F. Follow a TCP stream
1. Select a TCP packet.
2. Right-click and choose **Follow → TCP Stream**.
3. Inspect the reconstructed conversation, where available.

Encrypted protocols such as HTTPS generally do not expose application payload in readable form without appropriate decryption keys.

### G. Use coloring rules
1. Open **View → Coloring Rules**.
2. Review the default rules.
3. Add a custom rule using a display-filter expression if required.

## Example Packet List

| No. | Time | Source | Destination | Protocol | Length | Info |
|---:|---:|---|---|---|---:|---|
| 1 | 0.000000 | 192.168.1.10 | 192.168.1.1 | TCP | 66 | 50152 → 443 [SYN] |
| 2 | 0.012345 | 192.168.1.1 | 192.168.1.10 | TCP | 66 | 443 → 50152 [SYN, ACK] |
| 3 | 0.012456 | 192.168.1.10 | 192.168.1.1 | TCP | 54 | 50152 → 443 [ACK] |

*Illustrative example only. Actual packet addresses, lengths, protocols, and timestamps depend on the capture.*

## Input
- Live network interface with internet connectivity
- Optional pre-saved `.pcap` or `.pcapng` file

## Output
- Captured packets displayed in Wireshark
- Filtered traffic matching selected criteria
- Protocol Hierarchy, Endpoints, and Conversations statistics
- A saved capture file for offline analysis

## Constraints and Precautions
- Packet capture may require administrator/root privileges or capture-permission configuration.
- On a switched network, the capture usually shows traffic visible to the local interface; other devices' unicast traffic may not be visible unless suitable monitoring/port mirroring is configured.
- Captures on busy networks can become large. Use appropriate capture filters.
- HTTPS, SSH, and other encrypted traffic cannot normally be read as plaintext without the necessary decryption material.
- Capture only traffic you own or are authorized to inspect. Avoid collecting or sharing credentials, personal data, or other sensitive information.

## Result
Wireshark was studied as a network protocol analyzer. The procedure covers installation, packet capture, packet inspection, filtering, statistics, TCP stream following, and saving captures for offline analysis.

## Repository Contents
```text
wireshark-experiment-13/
├── README.md
└── outputs/
    └── README.md
```

Add your own screenshots and, if required by your instructor, a sanitized sample capture file to the `outputs/` folder. Do not upload captures containing sensitive information.
